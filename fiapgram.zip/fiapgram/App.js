import React from 'react';
import{FlatList} from  'react-native';
import Post from './components/Post';
import data from './data/data'

class App extends React.Component {
  render() { 
    
    return (
      <FlatList
      keyExtractor={item => item.picId.toString()}
      data={data.fotos}
      renderItem={  ({item})  =>  <Post foto={item} />
  } />
  
    );
  }
}

export default App;