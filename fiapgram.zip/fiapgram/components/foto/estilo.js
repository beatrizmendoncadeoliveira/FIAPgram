import {
    Dimensions,
    StyleSheet
} from 'react-native';

const width = Dimensions.get('screen').width;
const styles = StyleSheet.create({
  
    imagem: {
        height: width,
        width: width
    }
});

export default styles;