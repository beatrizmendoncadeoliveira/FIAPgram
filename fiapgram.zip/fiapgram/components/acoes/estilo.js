import{StyleSheet} from 'react-native'
const styles=StyleSheet.create({

  likeContainer : {
    flexDirection : 'row',
    alignItems : 'center'
  },
   heart : {
    color : 'red'
  },  
    
  textLikes : {
    marginLeft: 8
  },  
});
export default styles;
