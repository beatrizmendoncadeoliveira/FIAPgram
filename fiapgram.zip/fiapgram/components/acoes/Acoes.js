import React from 'react';
import {View,
        Text} from 'react-native';
import styles from './estilo'

import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faHeart as sHeart } from '@fortawesome/free-solid-svg-icons'
import { faHeart as rHeart } from '@fortawesome/free-regular-svg-icons'

const f=false;
export default class Acoes extends React.Component{
  render(){
    return(
      
 <View style={styles.likeContainer}>
         
            <FontAwesomeIcon 
              icon={f ? sHeart : rHeart }
              size={32}
              style={f ? styles.heart : {} }/>
            <Text style={ styles.textLikes }>2 curtidas</Text>
          </View>
          
    );   
  }
}