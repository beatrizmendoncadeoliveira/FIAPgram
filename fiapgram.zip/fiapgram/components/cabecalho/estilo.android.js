import{StyleSheet} from 'react-native';
const styles=StyleSheet.create({

  header : {
    flexDirection : 'row',
    alignItems : 'center',
    padding : 16
  },
  imgProfile : {
    height : 48, 
    width : 48,
    borderRadius : 50,
    marginRight : 8 
  },
  username : {
    fontFamily :'Roboto',
    fontSize : 16
  }
});
export default styles;
