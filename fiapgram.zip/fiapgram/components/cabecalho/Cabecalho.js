import React from 'react';
import {
    View,
    Image,
    Text
} from 'react-native';
import styles from './estilo.android';

export default class Cabecalho extends React.Component {
    render() {
        return (
            <View style={styles.header}>
                <Image
                    style={styles.imgProfile}
                    source={{ uri: this.props.src }} />
                <Text style={styles.username}>{this.props.usuario}</Text>
            </View>
        );
    }
}