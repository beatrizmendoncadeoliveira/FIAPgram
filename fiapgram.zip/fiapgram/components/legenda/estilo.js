import {StyleSheet} from 'react-native';

const styles=StyleSheet.create({
legend : {
    paddingVertical : 8
  },  
  userPost : {
    fontWeight : 'bold',
    marginRight : 16 
  }
});

export default styles;